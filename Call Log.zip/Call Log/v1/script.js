let calls = JSON.parse(localStorage.getItem('calls') || '[]');
let currentModalIndex = null;

/* Phone formatting */
function formatPhone(value){
  const digits = value.replace(/\D/g,'').slice(0,10);
  if(digits.length<=3) return digits;
  if(digits.length<=6) return `(${digits.slice(0,3)}) ${digits.slice(3)}`;
  return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6,10)}`;
}

function saveCalls(){ localStorage.setItem('calls', JSON.stringify(calls)); }
function escapeHtml(s){return s.toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

function renderCalls(filter=''){
  const tbody = document.querySelector('#callTable tbody');
  tbody.innerHTML='';
  const q = (filter||'').toLowerCase();
  calls.filter(c=>(
    (c.name||'').toLowerCase().includes(q) ||
    (c.number||'').includes(q) ||
    (c.email||'').toLowerCase().includes(q) ||
    (c.vehicle||'').toLowerCase().includes(q) ||
    (c.notes||'').toLowerCase().includes(q)
  )).forEach((call, idx)=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td>${call.timestamp}</td>
      <td><input value="${escapeHtml(call.name||'')}" onchange="editCall(${idx},'name',this.value)"></td>
      <td><input value="${escapeHtml(call.number||'')}" onchange="editCall(${idx},'number',formatPhoneInput(${idx},this.value))"></td>
      <td><input type="email" value="${escapeHtml(call.email||'')}" onchange="editCall(${idx},'email',this.value)"></td>
      <td><input value="${escapeHtml(call.vehicle||'')}" onchange="editCall(${idx},'vehicle',this.value)"></td>
      <td>
        <select onchange="editCall(${idx},'callType',this.value)">
          <option ${call.callType==='Incoming'?'selected':''}>Incoming</option>
          <option ${call.callType==='Outgoing'?'selected':''}>Outgoing</option>
          <option ${call.callType==='Missed'?'selected':''}>Missed</option>
        </select>
      </td>
      <td><textarea onchange="editCall(${idx},'notes',this.value)">${escapeHtml(call.notes||'')}</textarea></td>
      <td class="actions-col">
        <button class="btn subtle view-btn" data-idx="${idx}">View</button>
        <button class="btn danger" onclick="deleteCall(${idx})">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  propagateColumnVisibility();
}

function formatPhoneInput(index,value){ const f=formatPhone(value); calls[index].number=f; saveCalls(); return f; }
function editCall(index,field,value){ calls[index][field]=value; saveCalls(); }
function deleteCall(index){ if(!confirm('Delete this call?')) return; calls.splice(index,1); saveCalls(); renderCalls(document.getElementById('searchInput').value); }

/* Add form */
document.getElementById('addForm').addEventListener('submit',e=>{
  e.preventDefault();
  const newCall={timestamp:new Date().toLocaleString(),
    name:document.getElementById('name').value.trim(),
    number:formatPhone(document.getElementById('number').value),
    email:document.getElementById('email').value.trim(),
    vehicle:document.getElementById('vehicle').value.trim(),
    callType:document.getElementById('callType').value,
    notes:document.getElementById('notes').value.trim()};
  calls.push(newCall); saveCalls(); renderCalls(); e.target.reset();
});

/* Search */
document.getElementById('searchInput').addEventListener('input',e=>renderCalls(e.target.value));

/* Export all */
document.getElementById('exportBtn').addEventListener('click',()=>{
  let csv='Timestamp,Name,Phone,Email,Vehicle,Type,Notes\n';
  calls.forEach(c=>{csv+=`"${c.timestamp}","${c.name||''}","${c.number||''}","${c.email||''}","${c.vehicle||''}","${c.callType||''}","${(c.notes||'').replace(/"/g,'""')}"\n`;});
  const blob=new Blob([csv],{type:'text/csv'}); const url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download='call_log.csv'; a.click(); URL.revokeObjectURL(url);
});

/* Toggle log */
document.getElementById('toggleLogBtn').addEventListener('click',()=>{
  const w=document.getElementById('callLogWrapper'); const btn=document.getElementById('toggleLogBtn');
  if(w.style.display==='none'){ w.style.display=''; btn.textContent='Hide Call Log'; } else { w.style.display='none'; btn.textContent='Show Call Log'; }
});

/* Columns menu */
const columnsToggle=document.getElementById('columnsToggle');
const columnsDropdown=document.getElementById('columnsDropdown');
columnsToggle.addEventListener('click',()=>{columnsDropdown.classList.toggle('hidden');});
document.addEventListener('click',e=>{if(!columnsDropdown.classList.contains('hidden')&&!e.target.closest('.columns-menu')) columnsDropdown.classList.add('hidden');});
document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.addEventListener('change',propagateColumnVisibility));
document.getElementById('columnsReset').addEventListener('click',()=>{document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.checked=true); propagateColumnVisibility();});
function propagateColumnVisibility(){
  const table=document.getElementById('callTable'); const checks=Array.from(document.querySelectorAll('.columns-dropdown input[type="checkbox"]'));
  for(let r=0;r<table.rows.length;r++){const row=table.rows[r]; checks.forEach((cb,col)=>{if(row.cells[col]) row.cells[col].style.display=cb.checked?'':'none';});}
}

/* Modal setup */
const modal=document.getElementById('modal');
const closeBtn=modal.querySelector('.close-btn');
window.openModal=function(idx){
  currentModalIndex=idx;
  const c=calls[idx];
  document.getElementById('m_name').value=c.name||'';
  document.getElementById('m_number').value=c.number||'';
  document.getElementById('m_email').value=c.email||'';
  document.getElementById('m_vehicle').value=c.vehicle||'';
  document.getElementById('m_callType').value=c.callType||'Incoming';
  document.getElementById('m_notes').value=c.notes||'';
  modal.classList.remove('hidden');
};
closeBtn.addEventListener('click',()=>modal.classList.add('hidden'));
window.addEventListener('click',e=>{if(e.target===modal) modal.classList.add('hidden');});

/* Modal save/delete/export */
document.getElementById('modalForm').addEventListener('submit',e=>{
  e.preventDefault();
  const c=calls[currentModalIndex];
  c.name=document.getElementById('m_name').value.trim();
  c.number=formatPhone(document.getElementById('m_number').value);
  c.email=document.getElementById('m_email').value.trim();
  c.vehicle=document.getElementById('m_vehicle').value.trim();
  c.callType=document.getElementById('m_callType').value;
  c.notes=document.getElementById('m_notes').value.trim();
  saveCalls(); renderCalls(); modal.classList.add('hidden');
});
document.getElementById('modalDeleteBtn').addEventListener('click',()=>{
  if(!confirm('Delete this call?')) return;
  calls.splice(currentModalIndex,1); saveCalls(); renderCalls(); modal.classList.add('hidden');
});
document.getElementById('modalExportBtn').addEventListener('click',()=>{
  const c=calls[currentModalIndex];
  let csv='Timestamp,Name,Phone,Email,Vehicle,Type,Notes\n';
  csv+=`"${c.timestamp}","${c.name||''}","${c.number||''}","${c.email||''}","${c.vehicle||''}","${c.callType||''}","${(c.notes||'').replace(/"/g,'""')}"\n`;
  const blob=new Blob([csv],{type:'text/csv'}); const url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download='call_entry.csv'; a.click(); URL.revokeObjectURL(url);
});

/* Event delegation for view buttons */
document.querySelector('#callTable tbody').addEventListener('click', e=>{
  if(e.target.classList.contains('view-btn')){
    openModal(Number(e.target.dataset.idx));
  }
});

/* Initial render */
renderCalls();
