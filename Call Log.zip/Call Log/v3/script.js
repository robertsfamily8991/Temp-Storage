let calls = JSON.parse(localStorage.getItem('calls') || '[]');
let currentModalIndex = null;
let selectedDate = null;
let currentMonth = new Date();

function saveCalls(){ localStorage.setItem('calls', JSON.stringify(calls)); }
function escapeHtml(s){return s.toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function formatPhone(value){
  const digits=value.replace(/\D/g,'').slice(0,10);
  if(digits.length<=3) return digits;
  if(digits.length<=6) return `(${digits.slice(0,3)}) ${digits.slice(3)}`;
  return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6,10)}`;
}

/* Render Call Table */
function renderCalls(filter=''){
  const tbody = document.querySelector('#callTable tbody');
  tbody.innerHTML='';
  const q = (filter||'').toLowerCase();
  calls.filter(c=>{
    const dateMatch = selectedDate ? new Date(c.timestamp).toDateString()===selectedDate.toDateString() : true;
    const searchMatch = (c.name||'').toLowerCase().includes(q) ||
      (c.number||'').includes(q) ||
      (c.email||'').toLowerCase().includes(q) ||
      (c.vehicle||'').toLowerCase().includes(q) ||
      (c.notes||'').toLowerCase().includes(q);
    return dateMatch && searchMatch;
  }).forEach((call, idx)=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td>${call.timestamp}</td>
      <td>${escapeHtml(call.name||'')}</td>
      <td>${escapeHtml(call.number||'')}</td>
      <td>${escapeHtml(call.email||'')}</td>
      <td>${escapeHtml(call.vehicle||'')}</td>
      <td>${call.callType||''}</td>
      <td>${escapeHtml(call.notes||'')}</td>
      <td class="actions-col">
        <button class="btn subtle edit-btn" data-idx="${idx}">Edit</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  propagateColumnVisibility();
}

/* Column visibility */
function propagateColumnVisibility(){
  const table=document.getElementById('callTable'); 
  const checks=Array.from(document.querySelectorAll('.columns-dropdown input[type="checkbox"]'));
  for(let r=0;r<table.rows.length;r++){
    const row=table.rows[r]; 
    checks.forEach((cb,col)=>{if(row.cells[col]) row.cells[col].style.display=cb.checked?'':'none';});
  }
}

/* Calendar */
function renderCalendar(){
  const grid=document.getElementById('calendarGrid');
  grid.innerHTML='';
  const month=document.getElementById('calendarMonthYear');
  const year=currentMonth.getFullYear(), m=currentMonth.getMonth();
  month.textContent = currentMonth.toLocaleString('default',{month:'long', year:'numeric'});
  const firstDay=new Date(year,m,1).getDay();
  const daysInMonth=new Date(year,m+1,0).getDate();
  // blank cells
  for(let i=0;i<firstDay;i++){ const blank=document.createElement('div'); grid.appendChild(blank);}
  for(let d=1; d<=daysInMonth; d++){
    const dateCell=document.createElement('div'); 
    const dateObj=new Date(year,m,d);
    dateCell.className='calendar-cell';
    dateCell.textContent=d;
    const dayCalls = calls.filter(c=>new Date(c.timestamp).toDateString()===dateObj.toDateString());
    if(dayCalls.length) { dateCell.classList.add('has-calls'); dateCell.title=`${dayCalls.length} call(s)`; }
    if(selectedDate && dateObj.toDateString()===selectedDate.toDateString()) dateCell.classList.add('selected');
    dateCell.addEventListener('click',()=>{ selectedDate=dateObj; renderCalendar(); renderCalls(document.getElementById('searchInput').value); });
    grid.appendChild(dateCell);
  }
}

/* Add/Edit Modal */
const modal=document.getElementById('modal');
const modalTitle=document.getElementById('modalTitle');
const modalDeleteBtn=document.getElementById('modalDeleteBtn');

function openAddModal(){
  currentModalIndex=null;
  modalTitle.textContent='Add Call';
  modalDeleteBtn.classList.add('hidden');
  document.getElementById('m_name').value='';
  document.getElementById('m_number').value='';
  document.getElementById('m_email').value='';
  document.getElementById('m_vehicle').value='';
  document.getElementById('m_callType').value='Incoming';
  document.getElementById('m_notes').value='';
  modal.classList.remove('hidden');
}

function openEditModal(idx){
  currentModalIndex=idx;
  const c=calls[idx];
  modalTitle.textContent='Edit Call';
  modalDeleteBtn.classList.remove('hidden');
  document.getElementById('m_name').value=c.name||'';
  document.getElementById('m_number').value=c.number||'';
  document.getElementById('m_email').value=c.email||'';
  document.getElementById('m_vehicle').value=c.vehicle||'';
  document.getElementById('m_callType').value=c.callType||'Incoming';
  document.getElementById('m_notes').value=c.notes||'';
  modal.classList.remove('hidden');
}

/* Event Listeners */
document.getElementById('addCallBtn').addEventListener('click',openAddModal);
document.querySelector('.close-btn').addEventListener('click',()=>modal.classList.add('hidden'));
document.getElementById('modalCancelBtn').addEventListener('click',()=>modal.classList.add('hidden'));
document.querySelector('#callTable tbody').addEventListener('click', e=>{
  if(e.target.classList.contains('edit-btn')) openEditModal(Number(e.target.dataset.idx));
});

/* Modal Form Submit */
document.getElementById('modalForm').addEventListener('submit', e=>{
  e.preventDefault();
  const data={
    timestamp:new Date().toLocaleString(),
    name:document.getElementById('m_name').value.trim(),
    number:formatPhone(document.getElementById('m_number').value),
    email:document.getElementById('m_email').value.trim(),
    vehicle:document.getElementById('m_vehicle').value.trim(),
    callType:document.getElementById('m_callType').value,
    notes:document.getElementById('m_notes').value.trim()
  };
  if(currentModalIndex===null){ calls.push(data); }
  else{ 
    data.timestamp=calls[currentModalIndex].timestamp; // keep original
    calls[currentModalIndex]=data; 
  }
  saveCalls(); renderCalls(document.getElementById('searchInput').value); renderCalendar();
  modal.classList.add('hidden');
});

/* Delete */
modalDeleteBtn.addEventListener('click',()=>{
  if(!confirm('Delete this call?')) return;
  calls.splice(currentModalIndex,1); saveCalls(); renderCalls(); renderCalendar();
  modal.classList.add('hidden');
});

/* Search */
document.getElementById('searchInput').addEventListener('input',e=>renderCalls(e.target.value));

/* Export CSV */
document.getElementById('exportBtn').addEventListener('click',()=>{
  let csv='Timestamp,Name,Phone,Email,Vehicle,Type,Notes\n';
  calls.forEach(c=>{csv+=`"${c.timestamp}","${c.name||''}","${c.number||''}","${c.email||''}","${c.vehicle||''}","${c.callType||''}","${(c.notes||'').replace(/"/g,'""')}"\n`;});
  const blob=new Blob([csv],{type:'text/csv'}); const url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download='call_log.csv'; a.click(); URL.revokeObjectURL(url);
});

/* Toggle Log */
document.getElementById('toggleLogBtn').addEventListener('click',()=>{
  const w=document.getElementById('callLogWrapper'); const btn=document.getElementById('toggleLogBtn');
  if(w.style.display==='none'){ w.style.display=''; btn.textContent='Hide Call Log'; } else { w.style.display='none'; btn.textContent='Show Call Log'; }
});

/* Column menu */
const columnsToggle=document.getElementById('columnsToggle');
const columnsDropdown=document.getElementById('columnsDropdown');
columnsToggle.addEventListener('click',()=>{columnsDropdown.classList.toggle('hidden');});
document.addEventListener('click',e=>{if(!columnsDropdown.classList.contains('hidden')&&!e.target.closest('.columns-menu')) columnsDropdown.classList.add('hidden');});
document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.addEventListener('change',propagateColumnVisibility));
document.getElementById('columnsReset').addEventListener('click',()=>{document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.checked=true); propagateColumnVisibility();});

/* Calendar navigation */
document.getElementById('prevMonth').addEventListener('click',()=>{ currentMonth.setMonth(currentMonth.getMonth()-1); renderCalendar(); });
document.getElementById('nextMonth').addEventListener('click',()=>{ currentMonth.setMonth(currentMonth.getMonth()+1); renderCalendar(); });

/* Initial render */
renderCalendar(); renderCalls();
