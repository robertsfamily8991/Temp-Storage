let calls = JSON.parse(localStorage.getItem('calls') || '[]');
let currentModalIndex = null;
let currentMonth = new Date();
let selectedDate = null;
let showMonth = false;

function escapeHtml(s){return s.toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function formatPhone(value){ 
  const digits=value.replace(/\D/g,'').slice(0,10); 
  if(digits.length<=3)return digits; 
  if(digits.length<=6)return `(${digits.slice(0,3)}) ${digits.slice(3)}`; 
  return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6,10)}`; 
}
function saveCalls(){ localStorage.setItem('calls', JSON.stringify(calls)); }

/* Calendar */
function renderCalendar(){
  const grid=document.getElementById('calendarGrid'); 
  grid.innerHTML='';
  const monthYear=document.getElementById('calendarMonthYear');
  const year=currentMonth.getFullYear(), m=currentMonth.getMonth();
  monthYear.textContent=currentMonth.toLocaleString('default',{month:'long',year:'numeric'});

  const firstDay=new Date(year,m,1).getDay(); // 0 = Sun
  const daysInMonth=new Date(year,m+1,0).getDate();
  const today = new Date();

  // Leading empty cells
  for(let i=0;i<firstDay;i++){
    const emptyCell=document.createElement('div'); grid.appendChild(emptyCell);
  }

  for(let d=1;d<=daysInMonth;d++){
    const date=new Date(year,m,d);
    const cell=document.createElement('div'); 
    cell.className='calendar-cell';

    if(selectedDate && date.toDateString()===selectedDate.toDateString()) cell.classList.add('selected');
    if(date.toDateString()===today.toDateString()) cell.style.border='1px solid #ffb84d'; // highlight today

    const names=calls.filter(c=>{
      const callDate=new Date(c.timestamp);
      return callDate.toDateString()===date.toDateString();
    }).map(c=>c.name);

    if(names.length) cell.classList.add('has-calls');

    const dayDiv=document.createElement('div'); 
    dayDiv.textContent=d; 
    cell.appendChild(dayDiv);

    if(names.length){
      const namesDiv=document.createElement('div'); 
      namesDiv.className='cell-names';
      names.forEach((n,idx)=>{
        const span=document.createElement('span'); 
        span.textContent=n;
        span.addEventListener('click',(e)=>{
          e.stopPropagation();
          const callIndex=calls.findIndex(c=>c.name===n && new Date(c.timestamp).toDateString()===date.toDateString());
          if(callIndex>-1) openModal(callIndex);
        });
        namesDiv.appendChild(span);
      });
      cell.appendChild(namesDiv);
    }

    cell.addEventListener('click',()=>{
      selectedDate=date; 
      renderCalendar(); 
      renderCalls(document.getElementById('searchInput').value);
    });
    grid.appendChild(cell);
  }

  // Trailing empty cells to fill last row
  const totalCells = firstDay + daysInMonth;
  const trailing = (7 - (totalCells % 7)) % 7;
  for(let i=0;i<trailing;i++) grid.appendChild(document.createElement('div'));
}

/* Render calls */
function renderCalls(filter=''){
  const tbody=document.querySelector('#callTable tbody'); tbody.innerHTML='';
  const q=(filter||'').toLowerCase();
  calls.filter(c=>{
    const callDate=new Date(c.timestamp);
    if(!showMonth && selectedDate) if(callDate.toDateString()!==selectedDate.toDateString()) return false;
    if(showMonth) if(callDate.getMonth()!==currentMonth.getMonth() || callDate.getFullYear()!==currentMonth.getFullYear()) return false;
    return (c.name||'').toLowerCase().includes(q) || (c.number||'').includes(q) || (c.email||'').toLowerCase().includes(q) || (c.vehicle||'').toLowerCase().includes(q) || (c.notes||'').toLowerCase().includes(q);
  }).forEach((call,idx)=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td>${call.timestamp}</td>
      <td>${escapeHtml(call.name||'')}</td>
      <td>${escapeHtml(call.number||'')}</td>
      <td>${escapeHtml(call.email||'')}</td>
      <td>${escapeHtml(call.vehicle||'')}</td>
      <td>${call.callType||''}</td>
      <td>${escapeHtml(call.notes||'')}</td>
      <td class="actions-col">
        <button class="btn subtle view-btn" data-idx="${idx}">Edit</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

/* Modal */
const modal=document.getElementById('modal');
const closeBtn=modal.querySelector('.close-btn');
window.openModal=function(idx){
  currentModalIndex=idx;
  const c=calls[idx];
  document.getElementById('modalTitle').textContent='Edit Call';
  document.getElementById('m_name').value=c.name||'';
  document.getElementById('m_number').value=c.number||'';
  document.getElementById('m_email').value=c.email||'';
  document.getElementById('m_vehicle').value=c.vehicle||'';
  document.getElementById('m_callType').value=c.callType||'Incoming';
  document.getElementById('m_notes').value=c.notes||'';
  modal.classList.remove('hidden');
};
closeBtn.addEventListener('click',()=>modal.classList.add('hidden'));
document.getElementById('modalCancelBtn').addEventListener('click',()=>modal.classList.add('hidden'));

/* Add new call modal */
document.getElementById('addCallBtn').addEventListener('click',()=>{
  currentModalIndex=null;
  document.getElementById('modalTitle').textContent='Add Call';
  document.getElementById('modalForm').reset();
  modal.classList.remove('hidden');
});

/* Modal save/delete */
document.getElementById('modalForm').addEventListener('submit',e=>{
  e.preventDefault();
  const data={
    name:document.getElementById('m_name').value.trim(),
    number:formatPhone(document.getElementById('m_number').value),
    email:document.getElementById('m_email').value.trim(),
    vehicle:document.getElementById('m_vehicle').value.trim(),
    callType:document.getElementById('m_callType').value,
    notes:document.getElementById('m_notes').value.trim(),
    timestamp: currentModalIndex!==null ? calls[currentModalIndex].timestamp : new Date().toLocaleString()
  };
  if(currentModalIndex!==null) calls[currentModalIndex]=data;
  else calls.push(data);
  saveCalls(); renderCalendar(); renderCalls(); modal.classList.add('hidden');
});

document.getElementById('modalDeleteBtn').addEventListener('click',()=>{
  if(currentModalIndex===null) return;
  if(confirm('Delete this call?')){ calls.splice(currentModalIndex,1); saveCalls(); renderCalendar(); renderCalls(); modal.classList.add('hidden'); }
});

/* Event delegation for Edit buttons in table */
document.querySelector('#callTable tbody').addEventListener('click', e=>{
  if(e.target.classList.contains('view-btn')){
    openModal(Number(e.target.dataset.idx));
  }
});

/* Navigation & toggles */
document.getElementById('prevMonth').addEventListener('click',()=>{ currentMonth.setMonth(currentMonth.getMonth()-1); renderCalendar(); renderCalls(); });
document.getElementById('nextMonth').addEventListener('click',()=>{ currentMonth.setMonth(currentMonth.getMonth()+1); renderCalendar(); renderCalls(); });

const columnsToggle=document.getElementById('columnsToggle');
const columnsDropdown=document.getElementById('columnsDropdown');
columnsToggle.addEventListener('click',()=>columnsDropdown.classList.toggle('hidden'));
document.addEventListener('click',e=>{if(!columnsDropdown.classList.contains('hidden')&&!e.target.closest('.columns-menu')) columnsDropdown.classList.add('hidden');});
document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.addEventListener('change',()=>{
  const table=document.getElementById('callTable');
  const checks=Array.from(document.querySelectorAll('.columns-dropdown input[type="checkbox"]'));
  for(let r=0;r<table.rows.length;r++){ const row=table.rows[r]; checks.forEach((cb,col)=>{if(row.cells[col]) row.cells[col].style.display=cb.checked?'':'none';});}
}));
document.getElementById('columnsReset').addEventListener('click',()=>{
  document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.checked=true);
  document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.dispatchEvent(new Event('change')));
});

/* Toggle log visibility */
document.getElementById('toggleLogBtn').addEventListener('click',()=>{
  const w=document.getElementById('callLogWrapper');
  const btn=document.getElementById('toggleLogBtn');
  if(w.style.display==='none'){ w.style.display=''; btn.textContent='Hide Call Log'; }
  else { w.style.display='none'; btn.textContent='Show Call Log'; }
});

/* Month toggle button */
const monthToggleBtn=document.getElementById('monthToggleBtn');
monthToggleBtn.addEventListener('click',()=>{
  showMonth=!showMonth;
  monthToggleBtn.textContent=showMonth?'Showing All Calls for Month':'Show All Calls for Month';
  renderCalendar(); renderCalls(document.getElementById('searchInput').value);
});

/* Search input */
document.getElementById('searchInput').addEventListener('input',e=>renderCalls(e.target.value));

/* Export CSV */
document.getElementById('exportBtn').addEventListener('click',()=>{
  let csv='Timestamp,Name,Phone,Email,Vehicle,Type,Notes\n';
  calls.forEach(c=>{csv+=`"${c.timestamp}","${c.name||''}","${c.number||''}","${c.email||''}","${c.vehicle||''}","${c.callType||''}","${(c.notes||'').replace(/"/g,'""')}"\n`;});
  const blob=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='call_log.csv'; a.click(); URL.revokeObjectURL(a.href);
});

/* Initial render */
renderCalendar(); renderCalls();
