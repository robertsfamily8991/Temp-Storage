/* Script for enhanced Call Log */
const STORAGE_KEY = 'calls_v2';
const COLS_KEY = 'call_cols_v2';
const THEME_KEY = 'call_theme_v2';
const PAGE_KEY = 'call_page_v2';
const TEAM_BASE = '/api'; // backend base path; when team mode enabled frontend uses these endpoints

let calls = [];
let page = 1;
let perPage = 10;
let currentModalIndex = null;
let columnsState = null;
let teamMode = false;

function formatPhone(value){
  const digits = (value||'').replace(/\D/g,'').slice(0,10);
  if(digits.length <= 3) return digits;
  if(digits.length <= 6) return `(${digits.slice(0,3)}) ${digits.slice(3)}`;
  return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6,10)}`;
}
function validatePhone(value){
  const d = (value||'').replace(/\D/g,'');
  return d.length === 10;
}
function escapeHtml(s){ return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

/* Storage helpers */
function loadLocalCalls(){
  calls = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
}
function saveLocalCalls(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(calls));
}

/* Team mode helpers */
async function fetchRemoteCalls(){
  try{
    const res = await fetch(`${TEAM_BASE}/calls`);
    if(!res.ok) throw new Error('Failed to fetch');
    calls = await res.json();
  }catch(err){
    console.warn('Remote fetch failed', err);
    // fallback keep local
  }
}
async function pushRemoteCall(call){
  const res = await fetch(`${TEAM_BASE}/calls`, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(call)
  });
  return res.ok;
}
async function updateRemoteCall(id, call){
  const res = await fetch(`${TEAM_BASE}/calls/${id}`, {
    method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(call)
  });
  return res.ok;
}
async function deleteRemoteCall(id){
  const res = await fetch(`${TEAM_BASE}/calls/${id}`, { method:'DELETE' });
  return res.ok;
}

/* Columns state (persisted) */
function loadColumnsState(){
  const s = localStorage.getItem(COLS_KEY);
  if(s){ columnsState = JSON.parse(s); }
  else {
    columnsState = {0:true,1:true,2:true,3:true,4:true,5:true,6:true,7:true,8:true};
    localStorage.setItem(COLS_KEY, JSON.stringify(columnsState));
  }
  // apply to checkboxes in UI
  document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>{
    const i = Number(cb.dataset.col);
    cb.checked = !!columnsState[i];
  });
}
function saveColumnsState(){
  localStorage.setItem(COLS_KEY, JSON.stringify(columnsState));
}

/* Theme */
function loadTheme(){
  const t = localStorage.getItem(THEME_KEY) || 'dark';
  document.documentElement.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
}
function toggleTheme(){
  const cur = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
  const next = cur === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem(THEME_KEY, next);
}

/* Pagination helpers */
function totalPages(filtered){
  return Math.max(1, Math.ceil(filtered.length / perPage));
}
function clampPage(filtered){
  const tp = totalPages(filtered);
  if(page > tp) page = tp;
  if(page < 1) page = 1;
}

/* Render logic: build table rows programmatically (no inline handlers) */
function renderCalls(filterText=''){
  const tbody = document.querySelector('#callTable tbody');
  tbody.innerHTML = '';
  const q = (filterText||'').toLowerCase().trim();

  let filtered = calls.filter(c=>{
    const combined = `${c.name||''} ${c.number||''} ${c.email||''} ${c.vehicle||''} ${c.notes||''} ${ (c.tags||[]).join(' ')}`.toLowerCase();
    return combined.includes(q);
  });

  // sorting
  const sortBy = document.getElementById('sortBy').value || 'timestamp_desc';
  filtered.sort((a,b)=>{
    if(sortBy === 'timestamp_desc') return new Date(b.timestamp) - new Date(a.timestamp);
    if(sortBy === 'timestamp_asc') return new Date(a.timestamp) - new Date(b.timestamp);
    if(sortBy === 'name_asc') return (a.name||'').localeCompare(b.name||'');
    if(sortBy === 'name_desc') return (b.name||'').localeCompare(a.name||'');
    return 0;
  });

  // pagination
  perPage = Number(document.getElementById('perPage').value || 10);
  clampPage(filtered);
  const start = (page - 1) * perPage;
  const pageItems = filtered.slice(start, start + perPage);

  pageUpdateInfo(filtered);

  pageItems.forEach((call, idx)=>{
    const realIndex = calls.indexOf(call);
    const tr = document.createElement('tr');

    const makeCell = (inner) => {
      const td = document.createElement('td');
      td.innerHTML = inner;
      return td;
    };

    // Timestamp
    tr.appendChild(makeCell(escapeHtml(call.timestamp)));

    // Name (editable)
    const nameTd = document.createElement('td');
    const nameInput = document.createElement('input');
    nameInput.value = call.name || '';
    nameInput.addEventListener('change', e => { call.name = e.target.value.trim(); saveAndMaybePush(realIndex, call); renderCalls(q); });
    nameTd.appendChild(nameInput);
    tr.appendChild(nameTd);

    // Phone
    const phoneTd = document.createElement('td');
    const phoneInput = document.createElement('input');
    phoneInput.value = call.number || '';
    phoneInput.addEventListener('input', e => {
      e.target.value = formatPhone(e.target.value);
    });
    phoneInput.addEventListener('change', e => {
      call.number = formatPhone(e.target.value);
      saveAndMaybePush(realIndex, call);
      renderCalls(q);
    });
    phoneTd.appendChild(phoneInput);
    tr.appendChild(phoneTd);

    // Email
    const emailTd = document.createElement('td');
    const emailInput = document.createElement('input');
    emailInput.type = 'email';
    emailInput.value = call.email || '';
    emailInput.addEventListener('change', e => { call.email = e.target.value.trim(); saveAndMaybePush(realIndex, call); });
    emailTd.appendChild(emailInput);
    tr.appendChild(emailTd);

    // Vehicle
    const vehicleTd = document.createElement('td');
    const vehInput = document.createElement('input');
    vehInput.value = call.vehicle || '';
    vehInput.addEventListener('change', e => { call.vehicle = e.target.value.trim(); saveAndMaybePush(realIndex, call); });
    vehicleTd.appendChild(vehInput);
    tr.appendChild(vehicleTd);

    // Type
    const typeTd = document.createElement('td');
    const typeSelect = document.createElement('select');
    ['Incoming','Outgoing','Missed'].forEach(optText=>{
      const o = document.createElement('option'); o.textContent = optText; if(call.callType===optText) o.selected=true;
      typeSelect.appendChild(o);
    });
    typeSelect.addEventListener('change', e => { call.callType = e.target.value; saveAndMaybePush(realIndex, call); });
    typeTd.appendChild(typeSelect);
    tr.appendChild(typeTd);

    // Tags
    const tagsTd = document.createElement('td');
    const tagsInput = document.createElement('input');
    tagsInput.value = (call.tags||[]).join(', ');
    tagsInput.addEventListener('change', e => {
      call.tags = e.target.value.split(',').map(s=>s.trim()).filter(Boolean);
      saveAndMaybePush(realIndex, call);
    });
    tagsTd.appendChild(tagsInput);
    tr.appendChild(tagsTd);

    // Notes
    const notesTd = document.createElement('td');
    const notesArea = document.createElement('textarea');
    notesArea.rows = 2;
    notesArea.value = call.notes || '';
    notesArea.addEventListener('change', e => { call.notes = e.target.value; saveAndMaybePush(realIndex, call); });
    notesTd.appendChild(notesArea);
    tr.appendChild(notesTd);

    // Actions
    const actionsTd = document.createElement('td');
    actionsTd.classList.add('actions-col');
    const viewBtn = document.createElement('button'); viewBtn.className = 'btn subtle view-btn'; viewBtn.textContent = 'View';
    viewBtn.addEventListener('click', ()=> openModal(realIndex));
    const delBtn = document.createElement('button'); delBtn.className='btn danger'; delBtn.textContent='Delete';
    delBtn.addEventListener('click', ()=> deleteCall(realIndex));
    actionsTd.appendChild(viewBtn);
    actionsTd.appendChild(delBtn);
    tr.appendChild(actionsTd);

    tbody.appendChild(tr);
  });

  propagateColumnVisibility();
  renderCalendar(); // keep calendar in sync
}

function saveAndMaybePush(index, call){
  saveLocalCalls();
  if(teamMode && call.id!==undefined){
    updateRemoteCall(call.id, call).catch(()=>console.warn('remote update failed'));
  }
}

/* CRUD */
function addCallFromForm(e){
  e.preventDefault();
  const newCall = {
    timestamp: new Date().toISOString(),
    name: document.getElementById('name').value.trim(),
    number: formatPhone(document.getElementById('number').value),
    email: document.getElementById('email').value.trim(),
    vehicle: document.getElementById('vehicle').value.trim(),
    callType: document.getElementById('callType').value,
    tags: document.getElementById('tags').value.split(',').map(s=>s.trim()).filter(Boolean),
    notes: document.getElementById('notes').value.trim()
  };
  if(!validatePhone(newCall.number)){
    if(!confirm('Phone does not look like 10 digits. Add anyway?')) return;
  }

  if(teamMode){
    // push remote, server should return a full call with id
    pushRemoteCall(newCall).then(ok=>{
      if(ok){ fetchAllAndRender(); } else { alert('Failed to push to server.'); calls.push(newCall); saveLocalCalls(); renderCalls(); }
    }).catch(()=>{ calls.push(newCall); saveLocalCalls(); renderCalls(); });
  } else {
    // local
    calls.push(newCall);
    saveLocalCalls();
    renderCalls(document.getElementById('searchInput').value);
  }
  e.target.reset();
}

/* Delete */
function deleteCall(index){
  if(!confirm('Delete this call?')) return;
  const call = calls[index];
  if(teamMode && call.id!==undefined){
    deleteRemoteCall(call.id).then(ok=>{
      if(ok){ calls.splice(index,1); saveLocalCalls(); renderCalls(); }
      else alert('Failed to delete on server.');
    }).catch(()=>{calls.splice(index,1); saveLocalCalls(); renderCalls();});
  } else {
    calls.splice(index,1);
    saveLocalCalls();
    renderCalls(document.getElementById('searchInput').value);
  }
}

/* Modal */
const modal = document.getElementById('modal');
function openModal(idx){
  currentModalIndex = idx;
  const c = calls[idx];
  if(!c) return;
  document.getElementById('m_name').value = c.name||'';
  document.getElementById('m_number').value = c.number||'';
  document.getElementById('m_email').value = c.email||'';
  document.getElementById('m_vehicle').value = c.vehicle||'';
  document.getElementById('m_callType').value = c.callType||'Incoming';
  document.getElementById('m_tags').value = (c.tags||[]).join(', ');
  document.getElementById('m_notes').value = c.notes||'';
  modal.classList.remove('hidden');
}
document.querySelector('.close-btn').addEventListener('click', ()=> modal.classList.add('hidden'));
window.addEventListener('click', (e)=>{ if(e.target===modal) modal.classList.add('hidden'); });

document.getElementById('modalForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  if(currentModalIndex===null) return;
  const c = calls[currentModalIndex];
  c.name = document.getElementById('m_name').value.trim();
  c.number = formatPhone(document.getElementById('m_number').value);
  c.email = document.getElementById('m_email').value.trim();
  c.vehicle = document.getElementById('m_vehicle').value.trim();
  c.callType = document.getElementById('m_callType').value;
  c.tags = document.getElementById('m_tags').value.split(',').map(s=>s.trim()).filter(Boolean);
  c.notes = document.getElementById('m_notes').value.trim();
  saveLocalCalls();
  if(teamMode && c.id!==undefined) updateRemoteCall(c.id, c).catch(()=>console.warn('remote update failed'));
  renderCalls(document.getElementById('searchInput').value);
  modal.classList.add('hidden');
});
document.getElementById('modalDeleteBtn').addEventListener('click', ()=>{
  if(currentModalIndex===null) return;
  deleteCall(currentModalIndex);
  modal.classList.add('hidden');
});
document.getElementById('modalExportBtn').addEventListener('click', ()=>{
  if(currentModalIndex===null) return;
  const c = calls[currentModalIndex];
  let csv = 'Timestamp,Name,Phone,Email,Vehicle,Type,Tags,Notes\n';
  csv += `"${c.timestamp}","${c.name||''}","${c.number||''}","${c.email||''}","${c.vehicle||''}","${c.callType||''}","${(c.tags||[]).join(';')}","${(c.notes||'').replace(/"/g,'""')}"\n`;
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'call_entry.csv'; a.click(); URL.revokeObjectURL(url);
});

/* Export all */
document.getElementById('exportBtn').addEventListener('click', ()=>{
  let csv = 'Timestamp,Name,Phone,Email,Vehicle,Type,Tags,Notes\n';
  calls.forEach(c=>{
    csv += `"${c.timestamp}","${c.name||''}","${c.number||''}","${c.email||''}","${c.vehicle||''}","${c.callType||''}","${(c.tags||[]).join(';')}","${(c.notes||'').replace(/"/g,'""')}"\n`;
  });
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='call_log.csv'; a.click(); URL.revokeObjectURL(url);
});

/* Import CSV (simple parser) */
function parseCSV(text){
  // naive CSV parse – handles quoted fields and commas inside quotes
  const rows = [];
  const lines = text.split(/\r?\n/);
  const re = /(?:\"([^\"]*(?:\"\"[^\"]*)*)\"|([^,]+)|)(?:,|$)/g;
  for(let i=0;i<lines.length;i++){
    const row = [];
    let line = lines[i];
    if(!line.trim()) continue;
    re.lastIndex = 0;
    let m;
    while((m = re.exec(line)) && m[0] !== ''){
      let val = m[1] !== undefined ? m[1].replace(/\"\"/g,'"') : (m[2]||'');
      row.push(val);
      if(re.lastIndex >= line.length) break;
    }
    rows.push(row);
  }
  return rows;
}
document.getElementById('importBtn').addEventListener('click', ()=> document.getElementById('importFile').click());
document.getElementById('importFile').addEventListener('change', async (e)=>{
  const f = e.target.files[0];
  if(!f) return;
  const text = await f.text();
  const rows = parseCSV(text);
  // assume header exists
  const header = rows.shift().map(h=>h.toLowerCase());
  const mapped = rows.map(r=>{
    const obj = {};
    header.forEach((h,i)=> obj[h] = r[i] || '');
    return {
      timestamp: obj.timestamp || new Date().toISOString(),
      name: obj.name || '',
      number: formatPhone(obj.phone||obj.number||''),
      email: obj.email || '',
      vehicle: obj.vehicle || '',
      callType: obj.type || obj.calltype || 'Incoming',
      tags: (obj.tags||'').split(/;|,/).map(s=>s.trim()).filter(Boolean),
      notes: obj.notes || ''
    };
  });
  // append
  calls = calls.concat(mapped);
  saveLocalCalls();
  renderCalls(document.getElementById('searchInput').value);
  e.target.value = '';
});

/* Columns UI */
document.getElementById('columnsToggle').addEventListener('click', ()=> document.getElementById('columnsDropdown').classList.toggle('hidden'));
document.addEventListener('click', e=>{
  const dd = document.getElementById('columnsDropdown');
  if(!dd.classList.contains('hidden') && !e.target.closest('.columns-menu')) dd.classList.add('hidden');
});
document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>{
  cb.addEventListener('change', ()=>{
    columnsState[cb.dataset.col] = cb.checked;
    saveColumnsState();
    propagateColumnVisibility();
  });
});
document.getElementById('columnsReset').addEventListener('click', ()=>{
  Object.keys(columnsState).forEach(k => columnsState[k] = true);
  saveColumnsState();
  document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=> cb.checked = true);
  propagateColumnVisibility();
});
function propagateColumnVisibility(){
  const table = document.getElementById('callTable');
  const checks = columnsState;
  for(let r=0;r<table.rows.length;r++){
    const row = table.rows[r];
    for(const i in checks){
      if(row.cells[i]) row.cells[i].style.display = checks[i] ? '' : 'none';
    }
  }
}

/* Sorting & pagination UI */
document.getElementById('sortBy').addEventListener('change', ()=> renderCalls(document.getElementById('searchInput').value));
document.getElementById('perPage').addEventListener('change', ()=> { page = 1; renderCalls(document.getElementById('searchInput').value); });
document.getElementById('prevPage').addEventListener('click', ()=> { page = Math.max(1, page-1); renderCalls(document.getElementById('searchInput').value); });
document.getElementById('nextPage').addEventListener('click', ()=> { page = page + 1; renderCalls(document.getElementById('searchInput').value); });

function pageUpdateInfo(filtered){
  const tp = totalPages(filtered);
  document.getElementById('pageInfo').textContent = `${page} / ${tp}`;
}

/* Search */
document.getElementById('searchInput').addEventListener('input', (e)=> { page = 1; renderCalls(e.target.value); });

/* Toggle log wrapper */
document.getElementById('toggleLogBtn').addEventListener('click', ()=>{
  const w = document.getElementById('callLogWrapper'); const btn = document.getElementById('toggleLogBtn');
  if(w.style.display==='none'){ w.style.display=''; btn.textContent='Hide Call Log'; } else { w.style.display='none'; btn.textContent='Show Call Log'; }
});

/* Theme toggle */
document.getElementById('themeToggle').addEventListener('click', toggleTheme);

/* Import/Export & add */
document.getElementById('addForm').addEventListener('submit', addCallFromForm);

/* Calendar: simple month grid */
const calTitle = document.getElementById('calTitle');
const calendarEl = document.getElementById('calendar');
const dayEntriesEl = document.getElementById('dayEntries');
let calDate = new Date();

function startOfMonth(d){ return new Date(d.getFullYear(), d.getMonth(), 1); }
function endOfMonth(d){ return new Date(d.getFullYear(), d.getMonth()+1, 0); }

function renderCalendar(){
  calendarEl.innerHTML = '';
  const start = startOfMonth(calDate);
  const end = endOfMonth(calDate);
  calTitle.textContent = `${start.toLocaleString(undefined, {month:'long'})} ${start.getFullYear()}`;

  // determine weekday of 1st (0 Sun - 6 Sat)
  const startWeekday = start.getDay();
  // show days from previous month to fill
  const days = [];
  const prevCount = startWeekday;
  const prevMonthEnd = new Date(start.getFullYear(), start.getMonth(), 0).getDate();
  for(let i=prevCount-1;i>=0;i--) days.push(new Date(start.getFullYear(), start.getMonth()-1, prevMonthEnd - i));

  // days of current month
  for(let d=1; d<=end.getDate(); d++) days.push(new Date(start.getFullYear(), start.getMonth(), d));
  // fill to multiple of 7
  while(days.length % 7 !== 0) days.push(new Date(end.getFullYear(), end.getMonth()+1, days.length - (startWeekday + end.getDate()) + 1));

  // render cells
  days.forEach(day=>{
    const cell = document.createElement('div'); cell.className = 'cal-cell';
    const isThisMonth = day.getMonth() === start.getMonth();
    if(!isThisMonth) cell.style.opacity = '0.45';
    const dateSpan = document.createElement('div'); dateSpan.className='date'; dateSpan.textContent = day.getDate();
    cell.appendChild(dateSpan);

    // find calls on that day
    const dayIso = day.toISOString().slice(0,10);
    const dayCalls = calls.filter(c=>{
      const tsDay = new Date(c.timestamp).toISOString().slice(0,10);
      return tsDay === dayIso;
    });
    dayCalls.slice(0,3).forEach(c=>{
      const ev = document.createElement('span'); ev.className='cal-event'; ev.textContent = `${c.name || '(no name)'} — ${c.callType||''}`;
      ev.addEventListener('click', (e)=>{ e.stopPropagation(); showDayEntries(dayIso); });
      cell.appendChild(ev);
    });
    if(dayCalls.length > 3){
      const more = document.createElement('div'); more.className='cal-event'; more.textContent = `+${dayCalls.length-3} more`;
      more.addEventListener('click', (e)=>{ e.stopPropagation(); showDayEntries(dayIso); });
      cell.appendChild(more);
    }
    cell.addEventListener('click', ()=> showDayEntries(dayIso));
    calendarEl.appendChild(cell);
  });

  // hide dayEntries on render if empty
  if(!dayEntriesEl.classList.contains('hidden') && dayEntriesEl.dataset.date && dayEntriesEl.dataset.date.startsWith(start.toISOString().slice(0,7))) {
    // keep
  } else {
    dayEntriesEl.classList.add('hidden');
  }
}

function showDayEntries(dateIso){
  const entries = calls.filter(c => new Date(c.timestamp).toISOString().slice(0,10) === dateIso);
  dayEntriesEl.innerHTML = `<h4>Entries for ${dateIso}</h4>`;
  entries.forEach((c, idx)=>{
    const div = document.createElement('div'); div.style.padding='6px'; div.style.borderBottom='1px solid rgba(255,255,255,0.03)';
    div.innerHTML = `<strong>${escapeHtml(c.name||'(no name)')}</strong> <small>${escapeHtml(c.number||'')}</small><div>${escapeHtml(c.notes||'')}</div>`;
    const openBtn = document.createElement('button'); openBtn.className='btn subtle small'; openBtn.textContent='Open';
    openBtn.addEventListener('click', ()=> { openModal(calls.indexOf(c)); });
    div.appendChild(openBtn);
    dayEntriesEl.appendChild(div);
  });
  dayEntriesEl.dataset.date = dateIso;
  dayEntriesEl.classList.remove('hidden');
}

/* calendar nav */
document.getElementById('calPrev').addEventListener('click', ()=> { calDate = new Date(calDate.getFullYear(), calDate.getMonth()-1, 1); renderCalendar(); });
document.getElementById('calNext').addEventListener('click', ()=> { calDate = new Date(calDate.getFullYear(), calDate.getMonth()+1, 1); renderCalendar(); });

/* initial load */
async function init(){
  loadTheme();
  loadColumnsState();
  loadLocalCalls();

  // team mode checkbox toggle
  document.getElementById('teamMode').addEventListener('change', async (e) => {
    teamMode = e.target.checked;
    if(teamMode){
      await fetchAllAndRender();
    } else {
      loadLocalCalls();
      renderCalls();
    }
  });

  // set perPage from storage
  const savedPage = Number(localStorage.getItem(PAGE_KEY) || '1'); page = savedPage || 1;
  document.getElementById('perPage').value = perPage;

  // wire up other UI
  document.getElementById('toggleLogBtn').textContent = document.getElementById('callLogWrapper').style.display === 'none' ? 'Show Call Log' : 'Hide Call Log';
  document.getElementById('searchInput').value = '';

  // PWA: register service worker if supported
  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('sw.js').catch(()=>console.warn('sw failed'));
  }

  // initial render
  renderCalls();
}
async function fetchAllAndRender(){
  await fetchRemoteCalls();
  saveLocalCalls();
  renderCalls();
}

init();

/* small util: persist page number */
window.addEventListener('beforeunload', ()=> localStorage.setItem(PAGE_KEY, page.toString()));
