let calls = JSON.parse(localStorage.getItem('calls') || '[]');
let currentModalIndex = null;
let currentMonth = new Date();
let selectedDate = null;

/* Helpers */
function escapeHtml(s){return s.toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function formatPhone(value){ const digits=value.replace(/\D/g,'').slice(0,10); if(digits.length<=3)return digits; if(digits.length<=6)return `(${digits.slice(0,3)}) ${digits.slice(3)}`; return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6,10)}`; }
function saveCalls(){ localStorage.setItem('calls', JSON.stringify(calls)); }

/* Calendar */
function renderCalendar(){
  const grid=document.getElementById('calendarGrid'); grid.innerHTML='';
  const monthYear=document.getElementById('calendarMonthYear');
  const year=currentMonth.getFullYear(), m=currentMonth.getMonth();
  monthYear.textContent=currentMonth.toLocaleString('default',{month:'long', year:'numeric'});
  const firstDay=new Date(year,m,1).getDay();
  const daysInMonth=new Date(year,m+1,0).getDate();
  for(let i=0;i<firstDay;i++) grid.appendChild(document.createElement('div'));
  for(let d=1;d<=daysInMonth;d++){
    const dateCell=document.createElement('div');
    const dateObj=new Date(year,m,d);
    dateCell.className='calendar-cell'; dateCell.textContent=d;

    const dayCalls=calls.filter(c=>new Date(c.timestamp).toDateString()===dateObj.toDateString());
    if(dayCalls.length){
      dateCell.classList.add('has-calls');
      const namesDiv=document.createElement('div');
      namesDiv.className='cell-names';
      dayCalls.forEach((c,idx)=>{
        const span=document.createElement('span'); span.textContent=c.name||'Unnamed';
        span.addEventListener('click',e=>{
          e.stopPropagation();
          currentModalIndex=calls.indexOf(c);
          openModal(currentModalIndex);
        });
        namesDiv.appendChild(span);
      });
      dateCell.appendChild(namesDiv);
    }

    if(selectedDate && dateObj.toDateString()===selectedDate.toDateString()) dateCell.classList.add('selected');

    dateCell.addEventListener('click',()=>{
      selectedDate=dateObj; renderCalendar(); renderCalls(document.getElementById('searchInput').value);
    });

    grid.appendChild(dateCell);
  }
}

/* Render log */
function renderCalls(filter=''){
  const tbody=document.querySelector('#callTable tbody'); tbody.innerHTML='';
  const q=(filter||'').toLowerCase();
  const showMonth=document.getElementById('showMonthCalls')?.checked||false;
  calls.filter(c=>{
    const callDate=new Date(c.timestamp);
    const dateMatch=showMonth ? (callDate.getMonth()===currentMonth.getMonth()&&callDate.getFullYear()===currentMonth.getFullYear())
      : (selectedDate ? callDate.toDateString()===selectedDate.toDateString() : true);
    const searchMatch=(c.name||'').toLowerCase().includes(q)||(c.number||'').includes(q)||(c.email||'').toLowerCase().includes(q)||(c.vehicle||'').toLowerCase().includes(q)||(c.notes||'').toLowerCase().includes(q);
    return dateMatch && searchMatch;
  }).forEach((call,idx)=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`
      <td>${call.timestamp}</td>
      <td>${escapeHtml(call.name||'')}</td>
      <td>${escapeHtml(call.number||'')}</td>
      <td>${escapeHtml(call.email||'')}</td>
      <td>${escapeHtml(call.vehicle||'')}</td>
      <td>${call.callType||''}</td>
      <td>${escapeHtml(call.notes||'')}</td>
      <td class="actions-col"><button class="btn subtle edit-btn" data-idx="${idx}">Edit</button></td>
    `;
    tbody.appendChild(tr);
  });
}

/* Modal logic */
const modal=document.getElementById('modal');
const modalTitle=document.getElementById('modalTitle');
const closeBtn=modal.querySelector('.close-btn');
const modalDeleteBtn=document.getElementById('modalDeleteBtn');
const modalCancelBtn=document.getElementById('modalCancelBtn');

function openModal(idx=null){
  currentModalIndex=idx;
  if(idx===null){
    modalTitle.textContent='Add Call'; modalDeleteBtn.classList.add('hidden');
    document.getElementById('m_name').value='';
    document.getElementById('m_number').value='';
    document.getElementById('m_email').value='';
    document.getElementById('m_vehicle').value='';
    document.getElementById('m_callType').value='Incoming';
    document.getElementById('m_notes').value='';
  } else {
    const c=calls[idx];
    modalTitle.textContent='Edit Call'; modalDeleteBtn.classList.remove('hidden');
    document.getElementById('m_name').value=c.name||'';
    document.getElementById('m_number').value=c.number||'';
    document.getElementById('m_email').value=c.email||'';
    document.getElementById('m_vehicle').value=c.vehicle||'';
    document.getElementById('m_callType').value=c.callType||'Incoming';
    document.getElementById('m_notes').value=c.notes||'';
  }
  modal.classList.remove('hidden');
}

closeBtn.addEventListener('click',()=>modal.classList.add('hidden'));
modalCancelBtn.addEventListener('click',()=>modal.classList.add('hidden'));

/* Modal save */
document.getElementById('modalForm').addEventListener('submit',e=>{
  e.preventDefault();
  const c={
    timestamp:currentModalIndex===null ? new Date().toLocaleString() : calls[currentModalIndex].timestamp,
    name:document.getElementById('m_name').value.trim(),
    number:formatPhone(document.getElementById('m_number').value),
    email:document.getElementById('m_email').value.trim(),
    vehicle:document.getElementById('m_vehicle').value.trim(),
    callType:document.getElementById('m_callType').value,
    notes:document.getElementById('m_notes').value.trim()
  };
  if(currentModalIndex===null) calls.push(c); else calls[currentModalIndex]=c;
  saveCalls(); renderCalendar(); renderCalls(); modal.classList.add('hidden');
});

/* Modal delete */
modalDeleteBtn.addEventListener('click',()=>{
  if(confirm('Delete this call?')){
    calls.splice(currentModalIndex,1);
    saveCalls(); renderCalendar(); renderCalls(); modal.classList.add('hidden');
  }
});

/* Add Call button */
document.getElementById('addCallBtn').addEventListener('click',()=>openModal(null));

/* Edit buttons in table */
document.querySelector('#callTable tbody').addEventListener('click',e=>{
  if(e.target.classList.contains('edit-btn')) openModal(Number(e.target.dataset.idx));
});

/* Search & filters */
document.getElementById('searchInput').addEventListener('input',e=>renderCalls(e.target.value));
document.getElementById('showMonthCalls').addEventListener('change',()=>renderCalls(document.getElementById('searchInput').value));

/* Export CSV */
document.getElementById('exportBtn').addEventListener('click',()=>{
  let csv='Timestamp,Name,Phone,Email,Vehicle,Type,Notes\n';
  calls.forEach(c=>{csv+=`"${c.timestamp}","${c.name||''}","${c.number||''}","${c.email||''}","${c.vehicle||''}","${c.callType||''}","${(c.notes||'').replace(/"/g,'""')}"\n`;});
  const blob=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='call_log.csv'; a.click(); URL.revokeObjectURL(a.href);
});

/* Toggle log */
document.getElementById('toggleLogBtn').addEventListener('click',()=>{
  const w=document.getElementById('callLogWrapper');
  const btn=document.getElementById('toggleLogBtn');
  if(w.style.display==='none'){ w.style.display=''; btn.textContent='Hide Call Log'; }
  else { w.style.display='none'; btn.textContent='Show Call Log'; }
});

/* Calendar nav */
document.getElementById('prevMonth').addEventListener('click',()=>{ currentMonth.setMonth(currentMonth.getMonth()-1); renderCalendar(); renderCalls(); });
document.getElementById('nextMonth').addEventListener('click',()=>{ currentMonth.setMonth(currentMonth.getMonth()+1); renderCalendar(); renderCalls(); });

/* Columns dropdown */
const columnsToggle=document.getElementById('columnsToggle');
const columnsDropdown=document.getElementById('columnsDropdown');
columnsToggle.addEventListener('click',()=>columnsDropdown.classList.toggle('hidden'));
document.addEventListener('click',e=>{if(!columnsDropdown.classList.contains('hidden')&&!e.target.closest('.columns-menu')) columnsDropdown.classList.add('hidden');});
document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.addEventListener('change',()=>{
  const table=document.getElementById('callTable');
  const checks=Array.from(document.querySelectorAll('.columns-dropdown input[type="checkbox"]'));
  for(let r=0;r<table.rows.length;r++){ const row=table.rows[r]; checks.forEach((cb,col)=>{if(row.cells[col]) row.cells[col].style.display=cb.checked?'':'none';});}
}));
document.getElementById('columnsReset').addEventListener('click',()=>{
  document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.checked=true);
  document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.dispatchEvent(new Event('change')));
});

/* Initial render */
renderCalendar(); renderCalls();
