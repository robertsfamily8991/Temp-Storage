let calls = JSON.parse(localStorage.getItem('calls') || '[]');
let currentModalIndex = null;
let currentMonth = new Date();
let selectedDate = null;
let showMonth = false;
let showFollowups = false;

/* Helpers */
function escapeHtml(s){return s.toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function formatPhone(value){ const digits=value.replace(/\D/g,'').slice(0,10); if(digits.length<=3)return digits; if(digits.length<=6)return `(${digits.slice(0,3)}) ${digits.slice(3)}`; return `(${digits.slice(0,3)}) ${digits.slice(3,6)}-${digits.slice(6,10)}`; }
function saveCalls(){ localStorage.setItem('calls', JSON.stringify(calls)); }

/* Calendar */
function renderCalendar(){
  const grid=document.getElementById('calendarGrid'); grid.innerHTML='';
  const monthYear=document.getElementById('calendarMonthYear');
  const year=currentMonth.getFullYear(), m=currentMonth.getMonth();
  monthYear.textContent=currentMonth.toLocaleString('default',{month:'long',year:'numeric'});

  const firstDay=new Date(year,m,1).getDay();
  const daysInMonth=new Date(year,m+1,0).getDate();
  const today = new Date();

  for(let i=0;i<firstDay;i++){ grid.appendChild(document.createElement('div')); }

  for(let d=1;d<=daysInMonth;d++){
    const date=new Date(year,m,d);
    const cell=document.createElement('div'); cell.className='calendar-cell';
    if(selectedDate && date.toDateString()===selectedDate.toDateString()) cell.classList.add('selected');
    if(date.toDateString()===today.toDateString()) cell.style.border='2px solid #7cff7c';

    const names=calls.filter(c=>{
      const callDate=new Date(c.timestamp);
      return callDate.toDateString()===date.toDateString();
    }).map(c=>({name:c.name, followup:c.followup}));

    if(names.length) cell.classList.add('has-calls');

    const dayDiv=document.createElement('div'); dayDiv.textContent=d; cell.appendChild(dayDiv);

    if(names.length){
      const namesDiv=document.createElement('div'); namesDiv.className='cell-names';
      names.forEach(c=>{
        const span=document.createElement('span'); span.textContent=c.name;
        if(c.followup) span.classList.add('followup');
        span.addEventListener('click',(e)=>{
          e.stopPropagation();
          const callIndex=calls.findIndex(call=>call.name===c.name && new Date(call.timestamp).toDateString()===date.toDateString());
          if(callIndex>-1) openModal(callIndex);
        });
        namesDiv.appendChild(span);
      });
      cell.appendChild(namesDiv);
    }

    const hasFollowup = calls.some(c=>new Date(c.timestamp).toDateString()===date.toDateString() && c.followup);
    if(hasFollowup){
      const dot=document.createElement('div');
      dot.style.width='6px'; dot.style.height='6px'; dot.style.background='red';
      dot.style.borderRadius='50%'; dot.style.position='absolute'; dot.style.top='5px'; dot.style.right='5px';
      cell.appendChild(dot);
    }

    cell.addEventListener('click',()=>{ selectedDate=date; renderCalendar(); renderCalls(document.getElementById('searchInput').value); });
    grid.appendChild(cell);
  }
}

/* Render calls */
function renderCalls(filter=''){
  const tbody=document.querySelector('#callTable tbody'); tbody.innerHTML='';
  const q=(filter||'').toLowerCase();

  calls.filter(c=>{
    const callDate=new Date(c.timestamp);

    if(showFollowups && !c.followup) return false;
    else if(showMonth && !showFollowups){
      if(callDate.getMonth()!==currentMonth.getMonth() || callDate.getFullYear()!==currentMonth.getFullYear()) return false;
    } else if(!showMonth && !showFollowups && selectedDate){
      if(callDate.toDateString()!==selectedDate.toDateString()) return false;
    }

    return (c.name||'').toLowerCase().includes(q) || (c.number||'').includes(q) || (c.email||'').toLowerCase().includes(q) || (c.vehicle||'').toLowerCase().includes(q) || (c.notes||'').toLowerCase().includes(q);
  }).forEach((call,idx)=>{
    const tr=document.createElement('tr');
    tr.style.background=call.followup?'rgba(255,0,0,0.2)':'';
    tr.innerHTML=`
      <td>${call.timestamp}</td>
      <td>${escapeHtml(call.name||'')}</td>
      <td>${escapeHtml(call.number||'')}</td>
      <td>${escapeHtml(call.email||'')}</td>
      <td>${escapeHtml(call.vehicle||'')}</td>
      <td>${call.callType||''}</td>
      <td>${escapeHtml(call.notes||'')}</td>
      <td class="actions-col">
        <button class="btn subtle view-btn" data-idx="${idx}">Edit</button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  // **APPLY COLUMN VISIBILITY AFTER RENDER**
  const table = document.getElementById('callTable');
  const checks = Array.from(document.querySelectorAll('.columns-dropdown input[type="checkbox"]'));
  for (let r = 0; r < table.rows.length; r++) {
    const row = table.rows[r];
    checks.forEach((cb, col) => {
      if(row.cells[col]) row.cells[col].style.display = cb.checked ? '' : 'none';
    });
  }
}

/* Modal */
const modal=document.getElementById('modal');
const closeBtn=modal.querySelector('.close-btn');
window.openModal=function(idx){
  currentModalIndex=idx;
  const c=calls[idx];
  document.getElementById('modalTitle').textContent='Edit Call';
  document.getElementById('m_name').value=c.name||'';
  document.getElementById('m_number').value=c.number||'';
  document.getElementById('m_email').value=c.email||'';
  document.getElementById('m_vehicle').value=c.vehicle||'';
  document.getElementById('m_callType').value=c.callType||'Incoming';
  document.getElementById('m_notes').value=c.notes||'';
  document.getElementById('m_date').value=new Date(c.timestamp).toISOString().split('T')[0];
  document.getElementById('m_followup').checked=c.followup||false;
  modal.classList.remove('hidden');
};
closeBtn.addEventListener('click',()=>modal.classList.add('hidden'));
document.getElementById('modalCancelBtn').addEventListener('click',()=>modal.classList.add('hidden'));

/* Add new call modal */
document.getElementById('addCallBtn').addEventListener('click',()=>{
  currentModalIndex=null;
  document.getElementById('modalTitle').textContent='Add Call';
  document.getElementById('modalForm').reset();
  modal.classList.remove('hidden');
});

/* Modal save/delete */
document.getElementById('modalForm').addEventListener('submit',e=>{
  e.preventDefault();
  const selectedDateValue = document.getElementById('m_date').value;
  const timestamp = selectedDateValue 
    ? new Date(selectedDateValue + ' ' + new Date().toLocaleTimeString()).toLocaleString()
    : new Date().toLocaleString();

  const data={
    name:document.getElementById('m_name').value.trim(),
    number:formatPhone(document.getElementById('m_number').value),
    email:document.getElementById('m_email').value.trim(),
    vehicle:document.getElementById('m_vehicle').value.trim(),
    callType:document.getElementById('m_callType').value,
    notes:document.getElementById('m_notes').value.trim(),
    timestamp: timestamp,
    followup: document.getElementById('m_followup').checked
  };
  if(currentModalIndex!==null) calls[currentModalIndex]=data;
  else calls.push(data);
  saveCalls(); renderCalendar(); renderCalls(); modal.classList.add('hidden');
});

document.getElementById('modalDeleteBtn').addEventListener('click',()=>{
  if(currentModalIndex===null) return;
  if(confirm('Delete this call?')){ calls.splice(currentModalIndex,1); saveCalls(); renderCalendar(); renderCalls(); modal.classList.add('hidden'); }
});

/* Event delegation for Edit buttons in table */
document.querySelector('#callTable tbody').addEventListener('click', e=>{
  if(e.target.classList.contains('view-btn')){
    openModal(Number(e.target.dataset.idx));
  }
});

/* Navigation & toggles */
document.getElementById('prevMonth').addEventListener('click',()=>{ currentMonth.setMonth(currentMonth.getMonth()-1); renderCalendar(); renderCalls(); });
document.getElementById('nextMonth').addEventListener('click',()=>{ currentMonth.setMonth(currentMonth.getMonth()+1); renderCalendar(); renderCalls(); });

const columnsToggle=document.getElementById('columnsToggle');
const columnsDropdown=document.getElementById('columnsDropdown');
columnsToggle.addEventListener('click',()=>columnsDropdown.classList.toggle('hidden'));
document.addEventListener('click',e=>{if(!columnsDropdown.classList.contains('hidden')&&!e.target.closest('.columns-menu')) columnsDropdown.classList.add('hidden');});
document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.addEventListener('change',()=>{
  const table=document.getElementById('callTable');
  const checks=Array.from(document.querySelectorAll('.columns-dropdown input[type="checkbox"]'));
  for(let r=0;r<table.rows.length;r++){ const row=table.rows[r]; checks.forEach((cb,col)=>{if(row.cells[col]) row.cells[col].style.display=cb.checked?'':'none';});}
}));
document.getElementById('columnsReset').addEventListener('click',()=>{
  document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.checked=true);
  document.querySelectorAll('.columns-dropdown input[type="checkbox"]').forEach(cb=>cb.dispatchEvent(new Event('change')));
});

/* Toggle log visibility */
document.getElementById('toggleLogBtn').addEventListener('click',()=>{
  const w=document.getElementById('callLogWrapper');
  const btn=document.getElementById('toggleLogBtn');
  if(w.style.display==='none'){ w.style.display=''; btn.textContent='Hide Call Log'; }
  else { w.style.display='none'; btn.textContent='Show Call Log'; }
});

/* Month toggle button */
const monthToggleBtn=document.getElementById('monthToggleBtn');
monthToggleBtn.addEventListener('click',()=>{
  showMonth=!showMonth; showFollowups=false;
  monthToggleBtn.classList.toggle('accent',showMonth);
  followupsToggleBtn.classList.remove('accent');
  renderCalendar(); renderCalls(document.getElementById('searchInput').value);
});

/* Follow-ups toggle */
const followupsToggleBtn=document.getElementById('followupsToggleBtn');
followupsToggleBtn.addEventListener('click',()=>{
  showFollowups=!showFollowups; showMonth=false;
  followupsToggleBtn.classList.toggle('accent',showFollowups);
  monthToggleBtn.classList.remove('accent');
  renderCalendar(); renderCalls(document.getElementById('searchInput').value);
});

/* Search input */
document.getElementById('searchInput').addEventListener('input',e=>renderCalls(e.target.value));

/* Export CSV */
document.getElementById('exportBtn').addEventListener('click',()=>{
  let csv='Timestamp,Name,Phone,Email,Vehicle,Type,Notes,Follow-up\n';
  calls.forEach(c=>{
    csv+=`"${c.timestamp}","${c.name||''}","${c.number||''}","${c.email||''}","${c.vehicle||''}","${c.callType||''}","${(c.notes||'').replace(/"/g,'""')}","${c.followup?1:0}"\n`;
  });
  const blob=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='call_log.csv'; a.click(); URL.revokeObjectURL(a.href);
});

/* Initial render */
renderCalendar(); renderCalls();
