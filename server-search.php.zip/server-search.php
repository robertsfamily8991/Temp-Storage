<?php
// -------------------------
// Developer Search Tool
// -------------------------

//TO ACCESS : https://www.WEBSITE_URL.com/server-search.php

//Yes — even if it’s password protected, it’s still a security risk to leave a powerful search tool like this on a public server. Here’s why:

//Password protection isn’t bulletproof

//Basic HTTP auth (the one in this script) can be brute-forced if someone is persistent.

//Misconfigurations in the server or PHP could bypass it.

//Exposes sensitive files

//This tool can access all theme files, plugin files, and even server config files.

//Leaving it on the server is like leaving a skeleton key lying around, even if locked.

//Best practice

//Only upload it temporarily when you need it.

//Run your searches.

//Download/export results if needed.

//Delete it immediately afterward.

set_time_limit(0);
error_reporting(E_ALL);
ini_set('display_errors', 1);

// -------------------------
// 01. Password Protection
// -------------------------
$DST_USER = 'adminuser';       // CHANGE THIS
$DST_PASS = 'StrongPassword!'; // CHANGE THIS

if (php_sapi_name() !== 'cli') {
    if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW']) 
        || $_SERVER['PHP_AUTH_USER'] !== $DST_USER 
        || $_SERVER['PHP_AUTH_PW'] !== $DST_PASS) {

        header('WWW-Authenticate: Basic realm="Developer Search Tool"');
        header('HTTP/1.0 401 Unauthorized');
        echo 'Unauthorized access';
        exit;
    }
}

// -------------------------
// 02. Configuration
// -------------------------
$defaults = [
    'root' => defined('ABSPATH') ? ABSPATH : __DIR__,
    'term' => '',               
    'exts' => ['php','html','htm','js','css','json','txt','md','inc'],
    'skip_paths' => ['wp-content/uploads','.git','node_modules','vendor'],
    'max_file_size' => 5 * 1024 * 1024,
    'context_lines' => 2,
];

$config = $defaults;

if (php_sapi_name() === 'cli') {
    $argvTerm = isset($argv[1]) ? $argv[1] : null;
    $argvRoot = isset($argv[2]) ? $argv[2] : null;
    $argvContext = isset($argv[3]) ? (int)$argv[3] : null;
    if ($argvTerm) $config['term'] = $argvTerm;
    if ($argvRoot) $config['root'] = $argvRoot;
    if ($argvContext !== null) $config['context_lines'] = max(0,$argvContext);
} else {
    if (!empty($_REQUEST['root'])) $config['root'] = $_REQUEST['root'];
    if (!empty($_REQUEST['term'])) $config['term'] = $_REQUEST['term'];
    if (!empty($_REQUEST['context_lines'])) $config['context_lines'] = max(0, (int)$_REQUEST['context_lines']);
    if (!empty($_REQUEST['skip_uploads'])) $config['skip_paths'] = array_merge($config['skip_paths'], ['wp-content/uploads']);
}

$current_term = $config['term'];
$contextLines = $config['context_lines'];

// -------------------------
// 03. Clear Form
// -------------------------
if (!empty($_POST['clear_form'])) {
    $current_term = '';
    $config['root'] = $defaults['root'];
    $contextLines = $defaults['context_lines'];
    $out = [];
}

// -------------------------
// 04. Helper
// -------------------------
function file_is_binary($bytes) {
    if (strpos($bytes, "\0") !== false) return true;
    $len = min(strlen($bytes), 512);
    $nonprint = 0;
    for ($i=0;$i<$len;$i++){
        $c = ord($bytes[$i]);
        if ($c>126 || ($c<32 && $c!==9 && $c!==10 && $c!==13)) $nonprint++;
    }
    return ($nonprint / max(1,$len)) > 0.30;
}

// -------------------------
// 05. Show Form if empty
// -------------------------
if (php_sapi_name() !== 'cli' && empty($config['term'])) {
    ?>
    <!doctype html>
    <html><head><meta charset="utf-8"><title>Developer Search Tool</title>
    <style>
        /* Terminal Pro-inspired colors */
        * { font-family: "Courier New", Courier, monospace !important; box-sizing: border-box; }
        body { margin: 20px; background: #1D1F21; color: #C5C8C6; }
        h1 { margin-bottom: 5px; color: #8ABEB7; }
        .credit { color: #F0C674; margin-bottom: 20px; }
        input[type=text], input[type=number], input[type=checkbox], select, button { 
            background-color: #1D1F21; 
            color: #C5C8C6; 
            border: 1px solid #8ABEB7; 
            padding:5px; 
        }
        button:hover { background-color: #282A2E; color: #8ABEB7; }
        pre { white-space: pre-wrap; word-wrap: break-word; background:#1D1F21; padding:8px; color:#C5C8C6; border-left:3px solid #8ABEB7; }
        mark { background:#B5BD68; color:#1D1F21; font-weight:bold; }
    </style>
    </head><body>
    <h1>Developer Search Tool</h1>
    <div class="credit" style="padding-bottom:1rem; font-weight:bolder;">by John Roberts - Information Architect</div>

    <form method="post" style="margin-bottom:10px;">
      <label>Search term: <input name="term" style="width:360px" /></label><br/><br/>
      <label>Root folder (optional): <input name="root" style="width:360px" /></label><br/><br/>
      <label>Context lines: <input type="number" name="context_lines" value="2" style="width:60px;" min="0" /></label><br/><br/>
      <label><input type="checkbox" name="skip_uploads" value="1" checked /> Skip wp-content/uploads</label><br/><br/>
      <label>File types (comma-separated, e.g., php,html,js): 
          <input name="exts" style="width:360px" value="<?php echo implode(',', $config['exts']); ?>" />
      </label><br/><br/>
      <label>Limit to directory (optional): 
          <input name="subdir" style="width:360px" />
      </label><br/><br/>
      <button type="submit">Search</button>
      <button type="submit" name="clear_form" value="1">Clear Form</button>
    </form>

    <p style="color:#CC6666;"><strong>Security:</strong> remove this file when finished or restrict access.</p>
    </body></html>
    <?php
    exit;
}

// -------------------------
// 06. Filters
// -------------------------
$exts = $config['exts'];
if (!empty($_REQUEST['exts'])) {
    $exts = array_map('strtolower', array_map('trim', explode(',', $_REQUEST['exts'])));
}

$subdir = '';
$root = rtrim($config['root'], "/\\");
if (!empty($_REQUEST['subdir'])) {
    $subdir = trim($_REQUEST['subdir'], "/\\");
    $root = $root . DIRECTORY_SEPARATOR . $subdir;
    if (!is_dir($root)) {
        echo "<p style='color:#CC6666;'>Directory '$subdir' does not exist under root.</p>";
        $out = [];
    }
}

// -------------------------
// 07. Search Logic
// -------------------------
$out = [];

$rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS));

foreach ($rii as $file) {
    if (!$file->isFile()) continue;
    $path = $file->getRealPath();
    if (!$path) continue;

    $skip = false;
    foreach ($config['skip_paths'] as $sp) {
        if (strpos($path, DIRECTORY_SEPARATOR . trim($sp, '/\\') . DIRECTORY_SEPARATOR) !== false ||
            substr($path, -strlen($sp)) === $sp) { $skip = true; break; }
    }
    if ($skip) continue;

    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if ($ext !== '' && !in_array($ext, $exts)) continue;

    $size = $file->getSize();
    if ($size === false || $size > $config['max_file_size']) continue;

    $contents = @file_get_contents($path);
    if ($contents === false) continue;

    if (strpos(substr($contents,0,1024), "\0") !== false) continue; // skip binaries

    $contents_utf8 = @mb_convert_encoding($contents, 'UTF-8', 'auto');
    if ($contents_utf8 === false) continue;
    $contents = $contents_utf8;

    if (mb_stripos($contents, $config['term'], 0, 'UTF-8') === false) continue;

    $lines = preg_split("/\r\n|\n|\r/", $contents);
    $modified = date('Y-m-d H:i:s', $file->getMTime());

    foreach ($lines as $ln => $line) {
        if (mb_stripos($line, $config['term'], 0, 'UTF-8') !== false) {
            $startLine = max(0, $ln - $contextLines);
            $endLine = min(count($lines)-1, $ln + $contextLines);
            $snippetLines = [];
            for ($i = $startLine; $i <= $endLine; $i++) {
                $l = $lines[$i];
                $highlighted = preg_replace_callback('/(' . preg_quote($config['term'], '/') . ')/i', function($m){ return "\x01" . $m[1] . "\x02"; }, $l);
                $highlighted = htmlspecialchars($highlighted, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
                $highlighted = str_replace(["\x01","\x02"], ["<mark>","</mark>"], $highlighted);
                $snippetLines[] = ($i+1) . ": " . $highlighted;
            }

            $relative = str_replace($root . DIRECTORY_SEPARATOR, '', $path);
            $editable = 'External Editor (SSH/SFTP)';
            if (strpos($relative, 'wp-content/themes/') === 0) $editable = 'Theme Editor (WP)';
            if (strpos($relative, 'wp-content/plugins/') === 0) $editable = 'Plugin Editor (WP)';

            $out[] = [
                'file'=>$path,'relative'=>$relative,'line'=>$ln+1,
                'snippet'=>implode("\n",$snippetLines),
                'modified'=>$modified,'editable'=>$editable
            ];
        }
    }
}

// -------------------------
// 08. Download logic (CSV/HTML)
// -------------------------
if (!empty($_POST['download_csv']) && !empty($out)) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="developer_search_results.csv"');
    $f = fopen('php://output','w');
    fputcsv($f,['File','Line','Last Modified','Editable','Snippet']);
    foreach ($out as $m) fputcsv($f,[$m['file'],$m['line'],$m['modified'],$m['editable'],strip_tags($m['snippet'])]);
    fclose($f); exit;
}

if (!empty($_POST['download_html']) && !empty($out)) {
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="developer_search_results.html"');
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Developer Search Results</title></head><body>";
    echo "<style>*{font-family: \"Courier New\", Courier, monospace !important; box-sizing: border-box;} pre{background:#1D1F21;padding:8px;white-space:pre-wrap;word-wrap:break-word;color:#C5C8C6;border-left:3px solid #8ABEB7;} mark{background:#B5BD68;color:#1D1F21;font-weight:bold;}</style>";
    echo "<h1>Developer Search Results</h1>";
    foreach ($out as $m){
        echo "<div style='margin-bottom:20px;'><strong>File:</strong>".htmlspecialchars($m['file'])."<br>";
        echo "<strong>Line:</strong>".$m['line']." | <strong>Last Modified:</strong>".$m['modified']." | <strong>Editable:</strong>".htmlspecialchars($m['editable'])."<br>";
        echo "<pre>".$m['snippet']."</pre></div>";
    }
    echo "</body></html>"; exit;
}

// -------------------------
// 09-11. Display Form, Download Buttons, and Results with Terminal Pro Theme
// -------------------------
echo "<style>
* { font-family: 'Courier New', Courier, monospace !important; box-sizing: border-box; }
body { margin: 20px; background-color: #1D1F21; color: #C5C8C6; }
input, button, select, textarea { font-family: inherit; font-size: 14px; }
h1 { color: #8ABEB7; }
pre { background: #1D1F21; color: #C5C8C6; padding: 8px; white-space: pre-wrap; word-wrap: break-word; border-left: 3px solid #8ABEB7; }
mark { background-color: #B5BD68; color: #1D1F21; font-weight: bold; }
button { background-color: #1D1F21; color: #8ABEB7; border: 1px solid #8ABEB7; cursor: pointer; padding: 6px 12px; margin-right:5px; }
button:hover { background-color: #282A2E; }
label { display: block; margin-bottom: 8px; }
.credit { color: #F0C674; margin-bottom: 20px; }
a { color: #8ABEB7; text-decoration: none; }
a:hover { text-decoration: underline; }
</style>";

echo "<h1>Developer Search Tool</h1>
<div class='credit'>by John Roberts - Information Architect</div>";

echo "<form method='post' style='margin-bottom:10px;'>
<label>Search term: <input name='term' style='width:360px' value='".htmlspecialchars($current_term)."' /></label>
<label>Root folder: <input name='root' style='width:360px' value='".htmlspecialchars($config['root'])."' /></label>
<label>Context lines: <input type='number' name='context_lines' value='".htmlspecialchars($contextLines)."' style='width:60px;' min='0' /></label>
<label>File types: <input name='exts' style='width:360px' value='".htmlspecialchars(implode(',', $exts))."' /></label>
<label>Limit to directory: <input name='subdir' style='width:360px' value='".htmlspecialchars($subdir)."' /></label>
<label><input type='checkbox' name='skip_uploads' value='1' checked /> Skip wp-content/uploads</label>
<button type='submit'>Search</button>
<button type='submit' name='clear_form' value='1'>Clear Form</button>
</form>";

// Download Buttons
if (!empty($out)){
    echo "<form method='post' style='margin-bottom:20px;'>
    <input type='hidden' name='term' value='".htmlspecialchars($current_term)."'>
    <input type='hidden' name='root' value='".htmlspecialchars($config['root'])."'>
    <input type='hidden' name='context_lines' value='".htmlspecialchars($contextLines)."'>
    <input type='hidden' name='exts' value='".htmlspecialchars(implode(',', $exts))."'>
    <input type='hidden' name='subdir' value='".htmlspecialchars($subdir)."'>
    <button type='submit' name='download_csv' value='1'>Download CSV</button>
    <button type='submit' name='download_html' value='1'>Download HTML</button>
    </form>";
}

// Display Results
if (!empty($out)) {
    $files = [];
    foreach($out as $m) $files[$m['file']][] = $m;

    echo <<<HTML
<script>
function toggleFile(id){
    var e = document.getElementById(id);
    e.style.display = (e.style.display === 'none') ? 'block' : 'none';
}
</script>
HTML;

    echo "<ul>";
    $fileIndex = 0;
    foreach($files as $file => $matches){
        $fileIndex++;
        $divID = "filematches".$fileIndex;
        echo "<li style='margin-bottom:12px;'>
            <div style='cursor:pointer;color:#8ABEB7;' onclick=\"toggleFile('$divID')\">
                <strong>File:</strong> ".htmlspecialchars($file)." (click to expand/collapse)
            </div>";
        echo "<div id='$divID' style='display:none;margin-left:20px;margin-top:5px;'>";
        foreach($matches as $m){
            echo "<div><strong style='color:#C5C8C6;'>Line:</strong>".$m['line'].
                 " | <strong style='color:#C5C8C6;'>Last Modified:</strong>".$m['modified'].
                 " | <strong style='color:#C5C8C6;'>Editable:</strong>".htmlspecialchars($m['editable'])."</div>";
            echo "<pre>".$m['snippet']."</pre>";
        }
        echo "</div></li>";
    }
    echo "</ul>";
} else {
    echo "<p>No matches found.</p>";
}

echo "<p style='color:#CC6666;'><strong>Security reminder:</strong> delete this file when done or restrict access.</p>";
?>
